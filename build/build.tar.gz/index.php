<html>

<?php>  echo Hola a todos 
</html>